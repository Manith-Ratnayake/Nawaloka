from upstash_redis import Redis

redis = Redis(url="https://topical-gazelle-81142.upstash.io", token="********")

redis.set("foo", "bar")
value = redis.get("foo")